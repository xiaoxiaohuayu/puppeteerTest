<template>
  <div class="hello">
    <el-input v-model="msm"></el-input>
                            <img
                                :src="authCodeUrl"
                                alt
                                @click="loadAuthCode"
                        />
    <el-button @click="but()">button</el-button>
  </div>
</template>

<script>
import qs from 'qs'

import { login,dict,sss } from './api'
export default {
  name: 'HelloWorld',
  props: {

  },
  data () {
    return{
      authCodeUrl:'',
      msm:'',
    }
  },
  mounted(){

  },
  methods: {
    loadAuthCode(){
      console.log(sss)
        this.authCodeUrl ='https://jg.yimashuchi.com/paymentsupervision/auth/captcha_code?='+ new Date().getTime();
        // this.$axios.get(this.authCodeUrl)
        console.log(this.authCodeUrl,'this.authCodeUrl')
    },
    but() {
      let aoount ={
        'account':'admin',
        'password':123456,
        'captcha':this.msm,
      }
        let obj = qs.stringify(aoount);
      this.$axios.post(login,obj)
      // console.log(login,obj)
      // this.$axios.get('https://jg.yimashuchi.com'+dict)
      this.$axios.get(dict)
    }
  },
  created() {
    this.loadAuthCode()
  }

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
