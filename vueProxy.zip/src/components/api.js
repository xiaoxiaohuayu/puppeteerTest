export const login = '/paymentsupervision/auth/supervision_login';
export const dict = '/paymentsupervision/dict/all';
export const sss = "/auth/captcha_code?="