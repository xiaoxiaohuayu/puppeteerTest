// import ElementUI from 'element-ui'
import Vue from 'vue'
import App from './App.vue'
import Element from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(Element);
Vue.config.productionTip = false
    // 设置反向代理，前端请求默认发送到 http://jg.yimashuchi.com/paymentsupervision
var axios = require('axios')
    // axios.defaults.baseURL = 'http://jg.yimashuchi.com/paymentsupervision'
    // axios.defaults.baseURL = 'http://127.0.0.1:8080'
axios.defaults.withCredentials = true;
// 添加请求拦截器
axios.interceptors.request.use(function(config) {
    // document.cookie = "userId=828";
    // config.headers['Cookie'] = '123213123'
    console.log(config)
        // 在发送请求之前做些什么
    return config;
}, function(error) {
    // 对请求错误做些什么
    return Promise.reject(error);
})
console.log(axios)
    // 全局注册，之后可在其他组件中通过 this.$axios 发送数据
Vue.prototype.$axios = axios
new Vue({
    render: h => h(App),
}).$mount('#app')