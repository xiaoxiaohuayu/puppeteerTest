# vueproxy
2020/11/24
如果使用vue-cli中的devServer.proxy 的话注意几点：
1. 项目中有axios框架的话需要把`axios.defaults.baseURL` 注释掉。如果没有注释掉，会导致你的代理多一级目录（没有去证实）
2. 使用代理去处理的登录的时候，如果需要用到cookies并且后台设置cookies的HttpOnly为开启状态的话 不推荐用次方法去代理接口解决跨域，推荐nginx。当然后台未设置的话是可以的
3. 关于`pathRewrite`，个人感觉完全没有必要写.
实例：
    `  //vue-cli3.0 里面的 vue.config.js做配置
    devServer: {
        proxy: {
            '/rng': {     //这里最好有一个 /
                target: 'http://45.105.124.130:8081',  // 后台接口域名,后面没有/
                ws: true,        //如果要代理 websockets，配置这个参数
                secure: false,  // 如果是https接口，需要配置这个参数
                changeOrigin: true,  //是否跨域
                pathRewrite:{
                    '^/rng':''
                }
            }
        }
    }`
## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
